<?php
$this->register_module( 'wipe_repairbuddy', 'Wipe RepairBuddy from Server', 'Automatically clean and erase all RepairBuddy files.', 'home', false, true, false );
?>